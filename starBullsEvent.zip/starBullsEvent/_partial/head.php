<!--Uncomment when live<link href="https://fonts.googleapis.com/css?family=Oxygen|Padauk" rel="stylesheet">-->
<link href="https://fonts.googleapis.com/css?family=Material+Icons" rel="stylesheet">
<link href="css/font-awesome.min.css" rel="stylesheet">
<link href="css/bootstrap.min.css" rel="stylesheet">
<!--[if lt IE 9]> <script src=https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js></script> 
<script src=https://oss.maxcdn.com/respond/1.4.2/respond.min.js></script> <![endif]-->
<link href="css/freaking-custom.css" rel="stylesheet" />
<link href="css/style.css" rel="stylesheet" />

<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon">
<link rel="icon" href="img/favicon.ico" type="image/x-icon">